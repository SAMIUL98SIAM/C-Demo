﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using Castle.MicroKernel.Registration;

namespace FinalProject
{
    /// <summary>
    /// Interaction logic for CarAdd.xaml
    /// </summary>
    public partial class CarAdd : Window
    {
        public CarAdd()
        {
            InitializeComponent();
            //nextname.Content = "Hi mr. " + UserNam;
            //slot_book.Text = slotone;
            intime.IsEnabled = false;
            txtduration.IsEnabled = false;
            txtpayment.IsEnabled = false;
            

            Bindata();
            TimeUpdater();



        }
        async void TimeUpdater()
        {

            intime.Text = DateTime.Now.ToString();
            outtime.Text = DateTime.Now.ToString();
            await Task.Delay(1000);

        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PM9NGM3\SQLEXPRESS;Initial Catalog=PMS;Integrated Security=True");

        private void save_Click(object sender, RoutedEventArgs e)
        {

            if (carid.Text != "" && cartype.Text != "" && model.Text != "" && intime.Text!="" && outtime.Text!="" && slotgroup.Text!="")
            {

                try
                {
                    con.Open();

                    string newcon = "insert into CarAdd (carid, cartype, carmodel, duration, payment, slot_book, insertdate) values ('" + carid.Text + "','" + cartype.Text + "','" + model.Text + "', '" +txtduration.Text+ "','" +txtpayment.Text+ "','"+ slotgroup.Text +"' ,getdate())";
                    SqlCommand cmd = new SqlCommand(newcon, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesfully inserted");
                    Bindata();
                    TimeShow();



                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                     con.Close();
                }
            }
            else
            {
                MessageBox.Show("Invalid crediential");
            }

        }
        void TimeShow()
        {
            DateTime dtintime = DateTime.Parse(intime.Text);
            DateTime dtouttime = DateTime.Parse(outtime.Text);

            float duration = float.Parse((dtouttime - dtintime).TotalMinutes.ToString());
            var span = System.TimeSpan.FromMinutes(duration);
            var hour = ((int)span.TotalHours).ToString();
            var Minute = span.Minutes.ToString();
            txtduration.Text = hour + " Hour: " + "" + Minute +" Min";
            if((duration / 60) > 0)
            {
                if((duration / 60) <= 0.5)
                {
                    txtpayment.Text = "" + 0 + "$";
                }
                else
                {
                    txtpayment.Text = "" + (duration / 60) * 1 + "$";
                }
            }
        }



        void Bindata()
        {
            SqlCommand cmd = new SqlCommand("select * from CarAdd", con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.ItemsSource = dt.DefaultView;
            

        }

      

        private void search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (carid.Text != "")
                {
                    SqlCommand cmd = new SqlCommand("select * from CarAdd where carid='" + carid.Text+"'", con);
                    SqlDataAdapter sd = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sd.Fill(dt);
                    dataGridView1.ItemsSource = dt.DefaultView;
                }
                else
                {
                    MessageBox.Show("Please inter carid");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void logout(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Login entry = new Login();
            entry.ShowDialog();
            this.Close();
        }

        //private void back(object sender, RoutedEventArgs e)
        //{
        //    this.Hide(); 
        //    Slot entry = new Slot();
        //    entry.ShowDialog();
        //    this.Close();
        //}


        //private void update_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        con.Open();
        //        SqlCommand cmd = new SqlCommand("update CarAdd set carId ='" + carid.Text+ "',cartype = '" + cartype.Text + "', carmodel='" + model.Text + "', updatedate=getdate() where carid='" + carid.Text + "'", con);
        //        cmd.ExecuteNonQuery();

        //        MessageBox.Show("succesfully updated");
        //        Bindata();
        //    }
        //    catch(Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //}

        //private void delete_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        if (carid.Text != "")
        //        {
        //            //if(MessageBox.Show("Are you sure to delete?", "Delete Record", MessageBoxButton.YesNo))
        //            //{

        //            //}
        //            con.Open();
        //            SqlCommand cmd = new SqlCommand("Delete CarAdd where carid = '" + carid.Text + "'", con);
        //            cmd.ExecuteNonQuery();
        //            con.Close();
        //            MessageBox.Show("Succesfully Deleted");
        //            Bindata();
        //        }
        //        else
        //        {
        //            MessageBox.Show("Please insert carid");
        //        }

        //    }
        //    catch(Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}
    }
}
