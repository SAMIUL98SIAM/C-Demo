﻿using System;
using ContactListDemo.allData;
namespace ContactListDemo.io
{
    class Entry
    {
        static void Main(string[] args)
        {
           
            ParentSensorIOAbstract sio=null ;
            Console.WriteLine("What type of IO class u want to add in: ");
            string wtoi = Console.ReadLine();
            if (wtoi == "SIMPLE")
            {
                sio = new ContactIONoLogic();
            }
            //else  if (wtoi == "ARR")
            //{
            //    sio = new ContactIOArr();
            //}
            sio.showDetails();
        }
    }
}
