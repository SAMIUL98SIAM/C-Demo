﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContactListDemo.allData
{

    public enum relationType
    {
        FRIEND, FAMILY, BUSINESS
    }
    public enum ContactSize
    {
        BIG,SMALL
    }
}
