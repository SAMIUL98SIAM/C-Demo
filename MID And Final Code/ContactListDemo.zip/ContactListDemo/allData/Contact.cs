﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContactListDemo.allData
{
    struct Contact
    {
        public string name;
        public int phone;
        public string address;
        public relationType relation_type;
    }
}
