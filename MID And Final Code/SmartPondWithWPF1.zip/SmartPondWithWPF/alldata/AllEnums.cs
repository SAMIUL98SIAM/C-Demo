﻿namespace SmartFishFarm2.alldata
{
    public enum anotherenum
    {
        AAA, BBB, CCC
    }
    /// <summary>
    /// the enums for sensor types
    /// 
    /// </summary>
    public enum sensortypes
    {
        TEMP, PH, HUM
    }

    //will add pond size later
    public enum PondSize
    {
        BIG, MEDIUM, SMALL
    }
}