﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartFishFarm2
{
    /// <summary>
    /// the ponds class
    /// it will contain all sensors
    /// it will have specific size
    /// The number of sensors will depend on pond size
    /// </summary>
    class Ponds
    {
        //declare the array to hold the sensor data array
        //create a constructor that will accept the size of the pond so that the array size can be determined
    }
}
