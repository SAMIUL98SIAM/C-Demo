﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartFishFarm1.alldata
{
    class Sensor
    {
        byte sensor_id_temp;
        string sensor_type;//temp or ph
        string date_time1;//hard coded data, we should not use this
        double data1;
        string date_time2;
        double data2;
    }
}
